sc.FontSystem.prototype.tinyFont.charHeight++;
sc.FontSystem.prototype.tinyFont.reload();