sc.FontSystem.prototype.tinyFont.charHeight++;
sc.FontSystem.prototype.tinyFont.reload();
import "./js/custom-bgmPTBR.js";