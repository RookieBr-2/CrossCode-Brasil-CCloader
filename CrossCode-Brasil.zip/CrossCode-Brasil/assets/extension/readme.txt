Extensions are stored in this folders.

You can disable extensions by either deleting the folder or adding a '-' character at the start of the folder name.
Example: Rename the folder "ninja-skin" to "-ninja-skin" to disable it.

As extensões são armazenadas nestas pastas.

Você pode desabilitar as extensões excluindo a pasta ou adicionando um caractere '-' no início do nome da pasta.
Exemplo: Renomeie a pasta "ninja-skin" para "-ninja-skin" para desativá-la.